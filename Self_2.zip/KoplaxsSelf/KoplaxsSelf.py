# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
from bs4 import BeautifulSoup
import time, random, sys, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, urllib2, urllib3, wikipedia,tempfile,ast,glob,shutil,unicodedata,goslate
#import time,random,sys,json,codecs,threading,glob,re,os,subprocess

cl = LINETCR.LINE()
cl.login(token="EohEOplN9a4M63bTfCLc.m/nufNaIgUKwl1KyGZMY7a.YKsNE+p+zc6gVNUE87IWDpGCHBJmHNtef8B7yzbsA+8=")
#cl.login(qr=True)
cl.loginResult()

#ki = LINETCR.LINE()
#ki.login(token="EoQFhQB1DQVPRxsOrD78.fzUkY4NbgyYGAv4+b3SeAa.YsJ9bbGT89IuEmexHxuRkP4BxGnWeJm/PHmXjohA4yw=")
#ki.login(qr=True)
#ki.loginResult()

#ki2 = LINETCR.LINE()
#ki2.login(token="Eoz5e43YLEREL9cSaOec.m/nufNaIgUKwl1KyGZMY7a.8ZEitqGzbPgtclafIBY767tttlLyV1AyCIlshpXEwcA=")
#ki2.login(qr=True)
#ki2.loginResult()

#ki3 = LINETCR.LINE()
#ki3.login(token="EnC0Ecx0QBMMGP5HXMs7.oDm/kvcGEKxcrePbHPVPDW.kKAmDw7bGRhUSDhXU1xUushjRS+TkWt24WAeuCXzcAE=")
#ki3.login(qr=True)
#ki3.loginResult()

#ki4 = LINETCR.LINE()
#ki4.login(token="EnC0Ecx0QBMMGP5HXMs7.oDm/kvcGEKxcrePbHPVPDW.kKAmDw7bGRhUSDhXU1xUushjRS+TkWt24WAeuCXzcAE=")
#ki4.login(qr=True)
#ki4.loginResult()

#ki5 = LINETCR.LINE()
#ki5.login(token="EnC0Ecx0QBMMGP5HXMs7.oDm/kvcGEKxcrePbHPVPDW.kKAmDw7bGRhUSDhXU1xUushjRS+TkWt24WAeuCXzcAE=")
#ki5.login(qr=True)
#ki5.loginResult()

print "login success plak"
reload(sys)
sys.setdefaultencoding('utf-8')

helpMessage ="""╔═════════════
║      𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
║✰ ╠ ⭐ᖫ✧ᵐ.ʳ✧ᖭ ᵇᵒᵗ⭐  ╣✰
║      𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
║╔════════════
║╠🍁 Status/Set
║╠🍁 Mid
║╠🍁 Me
║╠🍁 Cek→Ctv
║╠🍁 Tagall
║╠🍁 Banlist
║╠🍁 Respon
║╠🍁 Info group/Ginfo
║╠🍁 Cancel
║╠🍁 Open/Close Qr
║╠🍁 Link
║╠🍁 Gn
║╠🍁 Mid @「 ᵗᵃᵍ 」
║╠🍁 Nk @「 ᵗᵃᵍ 」
║╠🍁 Qr on/off
║╠🍁 Cancel on/off
║╠🍁 Join on/off
║╠🍁 Share on/off
║╠🍁 Bot Add @「 ᵗᵃᵍ 」
║╠🍁 Bc
║╠🍁 Spam
║╠🍁 Tr id@en:
║╠🍁 Tr en@id:
║╠🍁 Tr id@ja:
║╠🍁 Tr ja@id:
║╠🍁 Instagram
║╠🍁 Cname:/MyName:
║╠🍁 Mr1/2 rename
║╠🍁 Allbio:
║╠🍁 Copy←→Backup
║╠🍁 List group/LG
║╠🍁 /invitemeto:
║╠🍁 SpamInvite
║╠🍁 Ban all
║╠🍁 Clear ban
║╠🍁 Like
║╠🍁 Like me
║╠🍁 Masuk/Gass
║╠🍁 Keluar/Cuss
║╠🍁 GassPoul
║╠🍁 Kado「 ᵗᵃᵍ 」
║╠🍁 Hay「 ᵗᵃᵍ 」
║╠🍁 Say
║╠🍁 Arespon on/off
║╠🍁 Lyric
║╠🍁 Music
║╠🍁 Cmusic
║╠🍁 Ytube
║╠🍁 #Ytube
║╠🍁 Video
║╠🍁 Setlast
║╠🍁 Viewlast
║╠🍁 Copy「ᵗᵃᵍ」
║╠🍁 Mr1/2 copy「ᵗᵃᵍ」
║╠🍁 Backup
║║★ⓈⒾⓁⒺⓃⓉ★
║╚════════════
║      𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
║✰ ╠ ⭐ᖫ✧ᵐ.ʳ✧ᖭ ᵇᵒᵗ⭐  ╣✰
║      𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
╚═════════════"""

Setgroup ="""╔═════════════
║  ⭐║ⓅⓇⓄⓉⒺⒸⓉ║⭐
║𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
║[Protect QR]
║- Qr on/off
║[Protect Join]
║- Protectoin on/off
║[Protect Cancel]
║- Cancel on/off
║[Mid Via Contact]
║- Contact on/off
║-[Cancel Invited]
║- Cancel all
║𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
║   ⭐ᖫ✧ᵐ.ʳ✧ᖭ ᵇᵒᵗ⭐  
║𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓
╚═════════════"""

KAC=[cl]
#KAC=[cl,ki,ki2]
mid = cl.getProfile().mid
#kimid = ki.getProfile().mid
#ki2mid = ki2.getProfile().mid
#ki3mid = ki3.getProfile().mid
#ki4mid = ki4.getProfile().mid
#ki5mid = ki5.getProfile().mid
Bots=[mid]
owner =["u33e3541670221ae9162f59188339b2ec"]#u072ed156baea3031e28be5b65ebb76a1
admin = ["u33e3541670221ae9162f59188339b2ec"]#u33e3541670221ae9162f59188339b2ec,"u159b8acb89c1198ca0695e3f077b0468"
wait = {
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":1},
    'leaveRoom':False,
    'timeline':True,
    'autoAdd':False,
    'message':"",
    "lang":"JP",
    "comment":"",
    "commentOn":False,
    "commentBlack":{},
    "detectMention":False,
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cName":"",
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Protectgr":True,
#    "Protectjoin":False,
    "Protectcancl":True,
    "Protectcancel":True,
    "protectionOn":True,
    "atjointicket":True
    }

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{},
    'copy':False,
    'target':{},
    'midsTarget':{}
    }

setTime = {}
setTime = wait2['setTime']

contact = cl.getProfile() 
backup = cl.getProfile() 
backup.dispalyName = contact.displayName 
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

#contact = ki.getProfile() 
#backup = ki.getProfile() 
#backup.dispalyName = contact.displayName 
#backup.statusMessage = contact.statusMessage
#backup.pictureStatus = contact.pictureStatus

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："] 
    for tex in tex:
      for command in commands:
        if string ==command:
          return True

def NOTIFIED_READ_MESSAGE(op):
    try:
        if op.param1 in wait2['readPoint']:
            Name = cl.getContact(op.param2).displayName
            if Name in wait2['readMember'][op.param1]:
                pass
            else:
                wait2['readMember'][op.param1] += "\n�9�9" + Name
                wait2['ROM'][op.param1][op.param2] = "�9�9" + Name
        else:
            pass
    except:
        pass

def bot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))
#==================================================================
#================== type cek cctv kaya siri =======================
        if op.type == 55:
             try:
               group_id = op.param1
               user_id=op.param2
               subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
             except Exception as e:
               print e
 #====================== DONE =====================================
        #------Protect Group Kick start------#
        if op.type == 11:
          if wait["Protectgr"] == True:
            if cl.getGroup(op.param1).preventJoinByTicket == False:
              if op.param2 in Bots:
                pass
              elif op.param2 in owner:
                pass
              elif op.param2 in admin:
                pass
              else:
              	try:
                	cl.sendText(op.param1,cl.getContact(op.param2).displayName + "")#Jangan Buka Kode QR Kk
                	cl.kickoutFromGroup(op.param1,[op.param2])
                	X = cl.getGroup(op.param1)
                	X.preventJoinByTicket = True
                	cl.updateGroup(X)
                	cl.sendText(op.param1,cl.getContact(op.param2).displayName + "\n" + "Kami Masukin Kedalam Blacklis Boss")
                	wait["blacklist"][op.param2] = True
                	f=codecs.open('st2__b.json','w','utf-8')
                	json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                except:
                	random.choice(KAC).sendText(op.param1,random.choice(KAC).getContact(op.param2).displayName + "")#Jangan Buka Kode QR Njiiir
                	random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                	X = random.choice(KAC).getGroup(op.param1)
                	X.preventJoinByTicket = True
                	random.choice(KAC).updateGroup(X)
                	random.choice(KAC).sendText(op.param1,random.choice(KAC).getContact(op.param2).displayName + "\n" + "Kami Masukin Kedalam Blacklis Boss")
                	wait["blacklist"][op.param2] = True
                	f=codecs.open('st2__b.json','w','utf-8')
                	json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
        #------Protect Group Kick finish-----#

        #------Cancel Invite User start------#
        if op.type == 13:
          if wait["Protectcancl"] == True:
            group = cl.getGroup(op.param1)
            gMembMids = [contact.mid for contact in group.invitee]
            if op.param2 not in Bots:
              if op.param2 in Bots:
                pass
              else:
                try:
                  cl.cancelGroupInvitation(op.param1, gMembMids)
                  cl.sendText(op.param1, "")#Mau Invite Siapa Plak ??? \nJangan Sok Jadi Jagoan Deh Lu Njir.\nAdmin Bukan,Owner Juga Bukan\Kick Ah �
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                except:
                  random.choice(KAC).cancelGroupInvitation(op.param1, gMembMids)
                  random.choice(KAC).sendText(op.param1, "")#Mau Invite Siapa Plak ??? \nJangan Sok Jadi Jagoan Deh Lu Njir.\nAdmin Bukan,Owner Juga Bukan\Kick Ah 😛
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
        #------Cancel Invite User Finish------#
            
        if op.type == 13:
            if mid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  cl.acceptGroupInvitation(op.param1)
                else:
                  cl.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"
                
            if kimid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  ki.acceptGroupInvitation(op.param1)
                else:
                  ki.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"
            
            if ki2mid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  ki2.acceptGroupInvitation(op.param1)
                else:
                  ki2.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"

            if ki3mid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  ki3.acceptGroupInvitation(op.param1)
                else:
                  ki3.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"

            if ki4mid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  ki4.acceptGroupInvitation(op.param1)
                else:
                  ki4.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"

            if ki5mid in op.param3:
              if wait["autoJoin"] == True:
                if op.param2 in Bots:
                  ki5.acceptGroupInvitation(op.param1)
                else:
                  ki5.rejectGroupInvitation(op.param1)
              else:
                print "autoJoin is Off"

        #------Joined User Kick start------#
#        if op.type == 17:
#          if wait["Protectjoin"] == True:
#            if op.param2 not in Bots:
#              if op.param2 in Bots:
#                pass
#              elif op.param2 in admin:
#                pass
#              elif op.param2 in owner:
#                pass
#              else:
#                try:
#                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
#                  cl.sendText(op.param1, "Protect Join nya On Boss\nMatiin dulu kalo mau Ada yang Gabung\nJoinn on/off")
#                except:
#                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
#                  cl.sendText(op.param1, "Protect Join nya On Boss\nMatiin dulu kalo mau Ada yang Gabung\nJoinn on/off")
        #------Joined User Kick start------#
        if op.type == 32: #Yang Cancel Invitan langsung ke kick
          if wait["Protectcancel"] == True:
            if op.param2 not in Bots:
              if op.param2 in Bots:
                pass
              elif op.param2 in admin:
                pass
              elif op.param2 in owner:
                pass
              else:
                random.choice(KAC).sendText(op.param1, "")#Jangan Sok Jadi Jagoan Deh Lu Njir.\nAdmin Bukan,Owner Juga Bukan\Kick Ah 😛
                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])   
        
        if op.type == 19:
          if op.param2 not in Bots:
            if op.param3 in mid:
              if op.param2 not in Bots:
                try:
                  ki.kickoutFromGroup(op.param1,[op.param2])
                  G = ki.getGroup(op.param1)
                  G.preventJoinByTicket = False
                  ki.updateGroup(G)
                  Ticket = ki.reissueGroupTicket(op.param1)
                  cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.001)
                  G = ki.getGroup(op.param1)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G = random.choice(KAC).getGroup(op.param1)
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.001)
                  G = random.choice(KAC).getGroup(op.param1)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True
                  
            if op.param3 in kimid:
              if op.param2 not in Bots:
                try:
                  G = cl.getGroup(op.param1)
                  cl.kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(op.param1)
                  ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.001)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  G = random.choice(KAC).getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True
                  
            if op.param3 in ki2mid:
              if op.param2 not in Bots:
                try:
                  G = ki.getGroup(op.param1)
                  ki.kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  ki.updateGroup(G)
                  Ticket = ki.reissueGroupTicket(op.param1)
                  ki2.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  G = random.choice(KAC).getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  ki2.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True

            if op.param3 in ki3mid:
              if op.param2 not in Bots:
                try:
                  G = ki2.getGroup(op.param1)
                  ki2.kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  ki2.updateGroup(G)
                  Ticket = ki2.reissueGroupTicket(op.param1)
                  ki3.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  ki2.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  G = random.choice(KAC).getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  ki3.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True

            if op.param3 in ki4mid:
              if op.param2 not in Bots:
                try:
                  G = ki3.getGroup(op.param1)
                  ki3.kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  ki3.updateGroup(G)
                  Ticket = ki3.reissueGroupTicket(op.param1)
                  ki4.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  ki3.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  G = random.choice(KAC).getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  ki4.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True

            if op.param3 in ki5mid:
              if op.param2 not in Bots:
                try:
                  G = ki4.getGroup(op.param1)
                  ki4.kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  ki4.updateGroup(G)
                  Ticket = ki3.reissueGroupTicket(op.param1)
                  ki5.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  ki4.updateGroup(G)
                  wait["blacklist"][op.param2] = True
                except:
                  G = random.choice(KAC).getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  G.preventJoinByTicket = False
                  random.choice(KAC).updateGroup(G)
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  ki5.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  random.choice(KAC).updateGroup(G)
                  wait["blacklist"][op.param2] = True

                  #--------------------------------                      
#=================================================================================
        if op.type == 26:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg.from_
            if msg.from_ == profile.mid:
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            X = cl.getGroup(list_[1])
                            X.preventJoinByTicket = True
                            cl.updateGroup(X)
                        except:
                            cl.sendText(msg.to,"error")
                    if msg.text in "@􀨁􀨁􀄆􏿿猫􀂳E􀂳‮􀂳🕕a􀂳i􀂳l􀂳i􀂳m":
                      try:
                          if wait["ResponTag"] == True:
                             panggil = msg.text.replace("@􀨁􀨁􀄆􏿿猫􀂳E􀂳‮􀂳🕕a􀂳i􀂳l􀂳i􀂳m","")
                             cl.sendText(msg.to,"Cie Ngetag:v")
                      except Exception as error:
                        print error
        if op.type == 26:
                    msg = op.message
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                      if wait["detectMention"] == True:
                            contact = cl.getContact(msg.from_)
                            cName = contact.displayName
                            balas = [" Jones yg doyan tag ini?",cName + " Ini foto org hilang",cName + " Contoh orang kurang belai nih",cName + " Jones diLarang keras sebut² nama gua (｀・ω・´)"]
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus                
                            ret_ = "Ciee Tag \n" + random.choice(balas)
                            name = re.findall(r'@(\w+)', msg.text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                   if mention['M'] in Bots:
                                          cl.sendText(msg.to,ret_)
                                          cl.sendImageWithURL(msg.to,path)
                                          break
#======================================================# 
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 25:
            msg = op.message


            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
            if msg.contentType == 16:
                url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                cl.like(url[25:58], url[66:], likeType=1001)
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
              if wait["wblack"] == True:
                if msg.contentMetadata["mid"] in wait["commentBlack"]:
                  cl.sendText(msg.to,"already")
                  wait["wblack"] = False
                else:
                  wait["commentBlack"][msg.contentMetadata["mid"]] = True
                  wait["wblack"] = False
                  cl.sendText(msg.to,"decided not to comment")
                  
              elif wait["dblack"] == True:
                if msg.contentMetadata["mid"] in wait["commentBlack"]:
                  del wait["commentBlack"][msg.contentMetadata["mid"]]
                  cl.sendText(msg.to,"deleted")
                  ki.sendText(msg.to,"deleted")
                  ki2.sendText(msg.to,"deleted")
                  ki3.sendText(msg.to,"deleted")
                  ki4.sendText(msg.to,"deleted")
                  ki5.sendText(msg.to,"deleted")
                  wait["dblack"] = False
                else:
                  wait["dblack"] = False
                  cl.sendText(msg.to,"It is not in the black list")
                  ki.sendText(msg.to,"It is not in the black list")
                  ki2.sendText(msg.to,"It is not in the black list")
                  ki3.sendText(msg.to,"It is not in the black list")
                  ki4.sendText(msg.to,"It is not in the black list")
                  ki5.sendText(msg.to,"It is not in the black list")
              elif wait["wblacklist"] == True:
                if msg.contentMetadata["mid"] in wait["blacklist"]:
                  cl.sendText(msg.to,"already")
                  ki.sendText(msg.to,"already")
                  ki2.sendText(msg.to,"already")
                  ki3.sendText(msg.to,"already")
                  ki4.sendText(msg.to,"already")
                  ki5.sendText(msg.to,"already")
                  wait["wblacklist"] = False
                else:
                  wait["blacklist"][msg.contentMetadata["mid"]] = True
                  wait["wblacklist"] = False
                  cl.sendText(msg.to,"aded")
                  ki.sendText(msg.to,"aded")
                  ki2.sendText(msg.to,"aded")
                  ki3.sendText(msg.to,"aded")
                  ki4.sendText(msg.to,"aded")
                  ki5.sendText(msg.to,"aded")
               
              elif wait["dblacklist"] == True:
                if msg.contentMetadata["mid"] in wait["blacklist"]:
                  del wait["blacklist"][msg.contentMetadata["mid"]]
                  cl.sendText(msg.to,"deleted")
                  ki.sendText(msg.to,"deleted")
                  ki2.sendText(msg.to,"deleted")
                  ki3.sendText(msg.to,"deleted")
                  ki4.sendText(msg.to,"deleted")
                  ki5.sendText(msg.to,"deleted")
                  wait["dblacklist"] = False
                else:
                  wait["dblacklist"] = False
                  cl.sendText(msg.to,"It is not in the black list")
                  ki.sendText(msg.to,"It is not in the black list")
                  ki2.sendText(msg.to,"It is not in the black list")
                  ki3.sendText(msg.to,"It is not in the black list")
                  ki4.sendText(msg.to,"It is not in the black list")
                  ki5.sendText(msg.to,"It is not in the black list")
              elif wait["contact"] == True:
                msg.contentType = 0
                cl.sendText(msg.to,msg.contentMetadata["mid"])
                if 'displayName' in msg.contentMetadata:
                  contact = cl.getContact(msg.contentMetadata["mid"])
                  try:
                    cu = cl.channel.getCover(msg.contentMetadata["mid"])
                  except:
                    cu = ""
                    cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                else:
                  contact = cl.getContact(msg.contentMetadata["mid"])
                  try:
                    cu = cl.channel.getCover(msg.contentMetadata["mid"])
                  except:
                    cu = ""
                    cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URLâ†’\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
            elif msg.text is None:
                return
            elif msg.text in ["Key","help","Help"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpMessage)
                else:
                    cl.sendText(msg.to,helpt)
            elif msg.text in ["Protect"]:
              #if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,Setgroup)
                else:
                    cl.sendText(msg.to,Sett)
            elif ("Gn " in msg.text):
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn ","")
                    cl.updateGroup(X)
                else:
                    cl.sendText(msg.to,"It can't be used besides the group.")
            elif ("Mr1 gn " in msg.text):
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Mr1 gn ","")
                    ki.updateGroup(X)
                else:
                    ki.sendText(msg.to,"It can't be used besides the group.")
            elif ("Mr2 gn " in msg.text):
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Mr2 gn ","")
                    ki2.updateGroup(X)
                else:
                    ki2.sendText(msg.to,"It can't be used besides the group.")
            elif "Kick " in msg.text:
                midd = msg.text.replace("Kick ","")
                random.choice(KAC).kickoutFromGroup(msg.to,[midd])
            elif "Mr1 kick " in msg.text:
                midd = msg.text.replace("Mr1 kick ","")
                ki.kickoutFromGroup(msg.to,[midd])
            elif "Mr2 kick " in msg.text:
              #if msg.from_ in admin:
                midd = msg.text.replace("Mr2 kick ","")
                ki2.kickoutFromGroup(msg.to,[midd])
            elif "Invite " in msg.text:
              #if msg.from_ in admin:
                midd = msg.text.replace("Invite ","")
                cl.findAndAddContactsByMid(midd)
                cl.inviteIntoGroup(msg.to,[midd])
            elif "Mr1 invite " in msg.text:
              #if msg.from_ in admin:
                midd = msg.text.replace("Mr1 invite ","")
                ki.findAndAddContactsByMid(midd)
                ki.inviteIntoGroup(msg.to,[midd])
            elif "Mr2 invite " in msg.text:
              #if msg.from_ in admin:
                midd = msg.text.replace("Mr2 invite ","")
                ki2.findAndAddContactsByMid(midd)
                ki2.inviteIntoGroup(msg.to,[midd])
            elif "Mr invite " in msg.text:
              #if msg.from_ in admin:
                midd = msg.text.replace("Bot invite ","")
                random.choice(KAC).findAndAddContactsByMid(midd)
                random.choice(KAC).inviteIntoGroup(msg.to,[midd])
    #--------------- SC Add Admin ---------
            elif "Admin add @" in msg.text:
              print "[Command]Staff add executing"
              _name = msg.text.replace("Admin add @","")
              _nametarget = _name.rstrip('  ')
              gs = cl.getGroup(msg.to)
              gs = ki.getGroup(msg.to)
              gs = ki2.getGroup(msg.to)
              gs = ki3.getGroup(msg.to)
              gs = ki4.getGroup(msg.to)
              gs = ki5.getGroup(msg.to)
              targets = []
              for g in gs.members:
                if _nametarget == g.displayName:
                  targets.append(g.mid)
              if targets == []:
                random.choice(KAC).sendText(msg.to,"Contact not found")
              else:
                for target in targets:
                  try:
                    admin.append(target)
                    cl.sendText(msg.to,"Admin Ditambahkan")
                  except:
                    pass
                #print "[Command]Staff add executed"
              #else:
                #cl.sendText(msg.to,"Command denied.")
                #cl.sendText(msg.to,"Admin permission required.")
                
            elif "Admin remove @" in msg.text:
                print "[Command]Staff remove executing"
                _name = msg.text.replace("Admin remove @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                gs = ki.getGroup(msg.to)
                gs = ki2.getGroup(msg.to)
                gs = ki3.getGroup(msg.to)
                gs = ki4.getGroup(msg.to)
                gs = ki5.getGroup(msg.to)
                #gs = k1.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                   random.choice(KAC).sendText(msg.to,"Contact not found")
                else:
                   for target in targets:
                        try:
                            admin.remove(target)
                            cl.sendText(msg.to,"Admin Dihapus")
                        except:
                            pass
                #print "[Command]Staff remove executed"
              #else:
                #cl.sendText(msg.to,"Command denied.")
                #cl.sendText(msg.to,"Admin permission required.")
                
            elif msg.text in ["Adminlist","adminlist"]:
              if admin == []:
                  cl.sendText(msg.to,"The stafflist is empty")
              else:
                  cl.sendText(msg.to,"Tunggu...")
                  mc = "||Admin ╠⌜ᵐ⁃ʳ⌟╣||\n=====================\n"
                  for mi_d in admin:
                      mc += "••>" +cl.getContact(mi_d).displayName + "\n"
                  cl.sendText(msg.to,mc)
                  print "[Command]Stafflist executed"
    #--------------------------------------
    #-------------- Add Friends ------------
            elif "Mr Add @" in msg.text:
              if msg.toType == 2:
                  print "[Command]Add executing"
                  _name = msg.text.replace("Mr Add @","")
                  _nametarget = _name.rstrip('  ')
                  gs = cl.getGroup(msg.to)
                  gs = ki.getGroup(msg.to)
                  gs = ki2.getGroup(msg.to)
                  gs = ki3.getGroup(msg.to)
                  gs = ki4.getGroup(msg.to)
                  gs = ki5.getGroup(msg.to)
                  targets = []
                  for g in gs.members:
                    if _nametarget == g.displayName:
                      targets.append(g.mid)
                  if targets == []:
                    random.choice(KAC).sendText(msg.to,"Contact not found")
                  else:
                    for target in targets:
                      try:
                        cl.findAndAddContactsByMid(target)
                        ki.findAndAddContactsByMid(target)
                        ki2.findAndAddContactsByMid(target)
                        ki3.findAndAddContactsByMid(target)
                        ki4.findAndAddContactsByMid(target)
                        ki5.findAndAddContactsByMid(target)
                      except:
                        cl.sendText(msg.to,"Error")
              #else:
                #cl.sendText(msg.to,"Perintah Ditolak")
                #cl.sendText(msg.to,"Perintah ini Hana Untuk Owner Kami")
                  
    #-------------=SC AllBio=----------------
            elif "Allbio:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Allbio:","")
                if len(string.decode('utf-8')) <= 500:
                    profile = cl.getProfile()
                    profile.statusMessage = string
                    cl.updateProfile(profile)
                if len(string.decode('utf-8')) <= 500:
                    profile = ki.getProfile()
                    profile.statusMessage = string
                    ki.updateProfile(profile)
                if len(string.decode('utf-8')) <= 500:
                    profile = ki2.getProfile()
                    profile.statusMessage = string
                    ki2.updateProfile(profile)
                if len(string.decode('utf-8')) <= 500:
                    profile = ki3.getProfile()
                    profile.statusMessage = string
                    ki3.updateProfile(profile)
                if len(string.decode('utf-8')) <= 500:
                    profile = ki4.getProfile()
                    profile.statusMessage = string
                    ki4.updateProfile(profile)
                if len(string.decode('utf-8')) <= 500:
                    profile = ki5.getProfile()
                    profile.statusMessage = string
                    ki5.updateProfile(profile)
    #--------------=Finish=----------------
    #--------------= SC Ganti nama Owner=--------------
            elif "MyName:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("MyName:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Update Name Menjadi : " + string + "")
            elif "Mr1Name:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr1Name:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki.getProfile()
                    profile.displayName = string
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"Update Name Menjadi : " + string + "")
            elif "Mr2Name:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr2Name:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki2.getProfile()
                    profile.displayName = string
                    ki2.updateProfile(profile)
                    ki2.sendText(msg.to,"Update Name Menjadi : " + string + "")
            elif "Mr3Name:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr3Name:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki3.getProfile()
                    profile.displayName = string
                    ki3.updateProfile(profile)
                    ki3.sendText(msg.to,"Update Name Menjadi : " + string + "")
            elif "Mr4Name:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr4Name:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki4.getProfile()
                    profile.displayName = string
                    ki4.updateProfile(profile)
                    ki4.sendText(msg.to,"Update Name Menjadi : " + string + "")
            elif "Mr5Name:" in msg.text:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr5Name:","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki5.getProfile()
                    profile.displayName = string
                    ki5.updateProfile(profile)
                    ki5.sendText(msg.to,"Update Name Menjadi : " + string + "")
    #-------------- copy profile----------
            elif "Spam " in msg.text:
                txt = msg.text.split(" ")
                jmlh = int(txt[2])
                teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                tulisan = jmlh * (teks+"\n")
                if txt[1] == "on":
                    if jmlh <= 500:
                       for x in range(jmlh):
                           cl.sendText(msg.to, teks)
                    else:
                       cl.sendText(msg.to, "Kelebihan batas:v")
                elif txt[1] == "off":
                    if jmlh <= 900:
                        cl.sendText(msg.to, tulisan)
                    else:
                        cl.sendText(msg.to, "Kelebihan batas :v")
    #-----------------=Selesai=------------------
            elif msg.text in ["All mid"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': kimid}
                ki.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': ki2mid}
                ki2.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': kimid}
                ki3.sendMessage(msg)                

                msg.contentType = 13
                msg.contentMetadata = {'mid': kimid}
                ki4.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': kimid}
                ki5.sendMessage(msg)

            elif msg.text in ["Me"]:
              ##if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                cl.sendMessage(msg)
            elif msg.text in ["Me"]:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                cl.sendMessage(msg)
            elif msg.text in ["Mr1"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': kimid}
                ki.sendMessage(msg)
            elif msg.text in ["Mr2"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': ki2mid}
                ki2.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","Gift"]:
              #if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                random.choice(KAC).sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","All gift"]:
              ##if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '12'}
                msg.text = None
                cl.sendMessage(msg)
                ki.sendMessage(msg)
                ki2.sendMessage(msg)
                
#======================================================# 
            elif "Bc: " in msg.text:
              if msg.from_ in Creator:
		bc = msg.text.replace("Bc: ","")
		gid = cl.getGroupIdsJoined()
		for i in gid:
		    cl.sendText(i,"[•=====BROADCAST=====•]\n\n"+bc+"\n\n================")
		cl.sendText(msg.to,"Yosh \n Done。")

            elif "#Broadcast:" in msg.text:
              if msg.from_ in admin:
                bctxt = msg.text.replace("#Broadcast:","")
                n = cl.getGroupIdsJoined()
                for manusia in n:
                    cl.sendText(manusia, (bctxt))
#======================================================# 
            elif msg.text in ["Cancel","cancel"]:
              ##if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Pendingan kosong BosQu")
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["bot cancel","Bot cancel"]:
            ##if msg.from_ in admin:
                if msg.toType == 2:
                    G = ki.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        ki.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ki.sendText(msg.to,"No one is inviting")
                        else:
                            ki.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ki.sendText(msg.to,"Not for use less than group")
            #elif "gurl" == msg.text:
                #print cl.getGroup(msg.to)
                ##cl.sendMessage(msg)
            elif msg.text in ["Buka qr","Open qr","Ourl","Open","Buka"]:
              ##if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"QR Sudah Dibuka")
                    else:
                        cl.sendText(msg.to,"Sudah Terbuka Boss")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Mr1 buka qr","Mr1 open qr"]:
                if msg.toType == 2:
                    X = ki.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Done")
                    else:
                        ki.sendText(msg.to,"already open")
                else:
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ki.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Mr2 buka qr","Mr2 open qr"]:
                if msg.toType == 2:
                    X = ki2.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ki2.updateGroup(X)
                    if wait["lang"] == "JP":
                        ki2.sendText(msg.to,"Done")
                    else:
                        ki2.sendText(msg.to,"already open")
                else:
                    if wait["lang"] == "JP":
                        ki2.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ki2.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Tutup qr","Close qr","Curl","Close","Tutup"]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Kode QR Sudah Di Tutup")
                    else:
                        cl.sendText(msg.to,"Sudah Tertutup Boss")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            
            elif "jointicket " in msg.text.lower():
		rplace=msg.text.lower().replace("jointicket ")
		if rplace == "on":
			wait["atjointicket"]=True
		elif rplace == "off":
			wait["atjointicket"]=False
		cl.sendText(msg.to,"Auto Join Group by Ticket is %s" % str(wait["atjointicket"]))
            elif '/ti/g/' in msg.text.lower():
		link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
		links = link_re.findall(msg.text)
		n_links=[]
		for l in links:
			if l not in n_links:
				n_links.append(l)
		for ticket_id in n_links:
			if wait["atjointicket"] == True:
				group=cl.findGroupByTicket(ticket_id)
				cl.acceptGroupInvitationByTicket(group.mid,ticket_id)
				cl.sendText(msg.to,"Sukses join ke grup %s" % str(group.name))
                     
            elif "Ginfo" == msg.text:
              if msg.toType == 2:
                if msg.from_ in admin:
                  ginfo = cl.getGroup(msg.to)
                  try:
                    gCreator = ginfo.creator.displayName
                  except:
                    gCreator = "Error"
                  if wait["lang"] == "JP":
                    if ginfo.invitee is None:
                      sinvitee = "0"
                    else:
                      sinvitee = str(len(ginfo.invitee))
                    if ginfo.preventJoinByTicket == True:
                      QR = "Close"
                    else:
                      QR = "Open"
                    cl.sendText(msg.to,"[Group Name]\n" + "〠" + str(ginfo.name) + "\n\n[Group ID]\n" + msg.to + "\n\n[Group Creator]\n" + "〠" + gCreator + "\n\n[Group Status]\n" + "〠Status QR =>" + QR + "\n\n[Group Picture]\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\n\nMembers:" + str(len(ginfo.members)) + "\nPending:" + sinvitee)
                  else:
                    cl.sendText(msg.to,"[Group Name]\n" + str(ginfo.name) + "\n\n[Group ID]\n" + msg.to + "\n\n[Group Creator]\n" + gCreator + "\n\n[Group Status]\nGroup Picture:\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                  if wait["lang"] == "JP":
                    cl.sendText(msg.to,"Can not be used outside the group")
                  else:
                    cl.sendText(msg.to,"Not for use less than group")
                
            #elif "My mid" == msg.text:
              #cl.sendText(msg.to, msg.from_)
            elif "Mid" == msg.text:
                cl.sendText(msg.to,mid)
            elif "Mid bot" == msg.text:
              ##if msg.from_ in admin:
                #cl.sendText(msg.to,mid)
                ki.sendText(msg.to,kimid)
                ki2.sendText(msg.to,ki2mid)
                
            elif msg.text in ["TL: "]:
              ##if msg.from_ in admin:
                tl_text = msg.text.replace("TL: ","")
                cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif msg.text in ["Mr1 rename "]:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr1 rename ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = ki.getProfile()
                    profile.displayName = string
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Mr2 rename "]:
              #if msg.from_ in admin:
                string = msg.text.replace("Mr2 rename ","")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = ki2.getProfile()
                    profile_B.displayName = string
                    ki2.updateProfile(profile_B)
                    ki2.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Mc "]:
              #if msg.from_ in admin:
                mmid = msg.text.replace("Mc ","")
                msg.contentType = 13
                msg.contentMetadata = {"mid":mmid}
                cl.sendMessage(msg)
            #---------------------------------------------------------
            elif "Cname:" in msg.text:
#              if msg.from_ in Creator:
                string = msg.text.replace("Cname:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------                
#-------------------- Protect Mode ------------
            elif msg.text in ["Allprotect on","Mode on"]:
#                if wait["Protectjoin"] == True:
#                    if wait["lang"] == "JP":
#                        cl.sendText(msg.to,"Kick Joined Group On􀜁􀇊􏿿")
#                    else:
#                        cl.sendText(msg.to,"Kick Joined Group On􀜁􀇊􏿿")
#                else:
#                    wait["Protectjoin"] = True
#                    if wait["lang"] == "JP":
##                        cl.sendText(msg.to,"Udah On")
#                    else:
#                        cl.sendText(msg.to,"Udah On")
                if wait["Protectcancl"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Invit On")
                    else:
                        cl.sendText(msg.to,"Invit on")
                else:
                    wait["Protectcancl"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Invit On")
                if wait["Protectcancel"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Cancel On")
                    else:
                        cl.sendText(msg.to,"Cancel on")
                else:
                    wait["Protectcancel"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Cancel On")
                if wait["protectionOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect On")
                    else:
                        cl.sendText(msg.to,"Done")
                else:
                    wait["protectionOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect On")
                    else:
                        cl.sendText(msg.to,"Done")
                if wait["Protectgr"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Link On")
                    else:
                        cl.sendText(msg.to,"Link On")
                else:
                    wait["Protectgr"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Link On")
                    else:
                        cl.sendText(msg.to,"done")

            elif msg.text in ["Allprotect off","Mode off"]:
#                if wait["Protectjoin"] == False:
#                    if wait["lang"] == "JP":
#                        cl.sendText(msg.to,"Kick Joined Group Off")
#                    else:
#                        cl.sendText(msg.to,"Kick Joined Gtoup Off�")
#                else:
#                    wait["Protectjoin"] = False
#                    if wait["lang"] == "JP":
#                        cl.sendText(msg.to,"Udah Mati Gblk")
#                    else:
#                        cl.sendText(msg.to,"Udah Mati Gblk")

                if wait["Protectcancl"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Invite Off")
                    else:
                        cl.sendText(msg.to,"Invite OFF")
                else:
                    wait["Protectcancl"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Invite Off")
                if wait["Protectcancel"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Cancel Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectcancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect Cancel Off")
                if wait["protectionOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Block Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["protectionOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Block Off")
                    else:
                        cl.sendText(msg.to,"done")
                if wait["Protectgr"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectgr"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR Off")
                    else:
                        cl.sendText(msg.to,"done")
#----------------------------------------------
            elif msg.text in ["Protectjoin on","protectjoin on"]:
              #if msg.from_ in admin:
                if wait["Protectjoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Kick Joined Group On")
                    else:
                        cl.sendText(msg.to,"Done")
                else:
                    wait["Protectjoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Kick Joined Group On")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Protectjoin off","protectjoin off"]:
              #if msg.from_ in admin:
                if wait["Protectjoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"kick Joined Group Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectjoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"kick Joined Group Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Cancel on","cancel on"]:
              #if msg.from_ in admin:
                if wait["Protectcancl"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cancel Semua Undangan On")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectcancl"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cancel Semua Undangan On")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Cancel off","cancel off"]:
              #if msg.from_ in admin:
                if wait["Protectcancl"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cancel Semua Undangan Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectcancl"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cancel Semua Undangan Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Invite on","invite on"]:
              #if msg.from_ in admin:
                if wait["Protectcancel"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Yang Cancel Undangan Kami Kick")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectcancel"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Yang Cancel Undangan Kami Kick")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Cancel off","cancel off"]:
              #if msg.from_ in admin:
                if wait["Protectcancel"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Yang Cancel Undangan Tidak Kami Kick")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectcancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Yang Cancel Undangan Tidak Kami Kick")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Qr on","qr on"]:
              #if msg.from_ in admin:
                if wait["Protectgr"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR On")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectgr"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR On")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Qr off","qr off"]:
              #if msg.from_ in admin:
                if wait["Protectgr"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["Protectgr"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Contact On","Contact on","contact on"]:
              #if msg.from_ in admin:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Lewat Share Kontak On")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Lewat Share Kontak On")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Contact Off","Contact off","contact off"]:
              #if msg.from_ in admin:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Lewat Share Kontak Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Lewat Share Kontak Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["è‡ªå‹•å�‚åŠ :ã‚ªãƒ³","Join on","Auto join on","è‡ªå‹•å�ƒåŠ ï¼šé–‹"]:
              #if msg.from_ in admin:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["è‡ªå‹•å�‚åŠ :ã‚ªãƒ•","Join off","Auto join off","è‡ªå‹•å�ƒåŠ ï¼šé—œ"]:
              #if msg.from_ in admin:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
#======================================================# 
            elif msg.text in ["Gcancel:"]:
                try:
                    strnum = msg.text.replace("Gcancel:","")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"å…³äº†é‚€è¯·æ‹’ç»�ã€‚è¦�æ—¶å¼€è¯·æŒ‡å®šäººæ•°å�‘é€�")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + "The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "ä½¿äººä»¥ä¸‹çš„å°�ç»„ç”¨è‡ªåŠ¨é‚€è¯·æ‹’ç»�")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")
#======================================================# 
            elif msg.text in ["å¼·åˆ¶è‡ªå‹•é€€å‡º:ã‚ªãƒ³","Leave on","Auto leave:on","å¼·åˆ¶è‡ªå‹•é€€å‡ºï¼šé–‹"]:
              #if msg.from_ in admin:
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["å¼·åˆ¶è‡ªå‹•é€€å‡º:ã‚ªãƒ•","Leave off","Auto leave:off","å¼·åˆ¶è‡ªå‹•é€€å‡ºï¼šé—œ"]:
              #if msg.from_ in admin:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already")
            elif msg.text in ["å…±æœ‰:ã‚ªãƒ³","Share on","Share on"]:
              #if msg.from_ in admin:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["å…±æœ‰:ã‚ªãƒ•","Share off","Share off"]:
              #if msg.from_ in admin:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
#======================================================# 
            elif msg.text in ["Like on","Auto like on"]:
              if msg.from_ in admin: 
                if wait["likeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["likeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Auto like off","Like off"]:
              if msg.from_ in admin:
                if wait["likeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["likeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Tag on","Respon tag on"]:
              if msg.from_ in admin:
                if wait["ResponTag"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["ResponTag"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Tag off","Respon tag off"]:
              if msg.from_ in admin:
                if wait["ResponTag"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["ResponTag"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Status","Set","Set view"]:
              #if msg.from_ in admin:
                md = "  ⭐s̶̺t̶̺a̶̺t̶̺u̶̺s̶̺ ̶p̶̺r̶̺o̶̺t̶̺e̶̺c̶̺t̶̺⭐\n𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓\n"
                if wait["Protectcancel"] == True: md+="〠Protect Cancel「On」\n"
                else: md+="〠Protect Cancel「Off」\n"
#                if wait["Protectjoin"] == True: md+="〠Protect Group「On」\n"
#                else: md+="〠Protect Group「Off」\n"
                if wait["Protectgr"] == True: md+="〠Protect QR「On」\n"
                else: md+="〠Protect QR「Off」\n"
                if wait["Protectcancl"] == True: md+="〠Protect Invite「On」\n"
                else: md+="〠Protect Invite「Off」\n"
                if wait["contact"] == True: md+="〠Contact「On」\n"
                else: md+="〠Contact「Off」\n"
                if wait["autoJoin"] == True: md+="〠Auto Join「On」\n"
                else: md +="〠Auto Join「Off」\n"
                if wait["autoCancel"]["on"] == True:md+="〠Group Cancel " + str(wait["autoCancel"]["members"]) + "\n"
                else: md+= "〠Group Cancel「Off」\n"
                if wait["leaveRoom"] == True: md+="〠Auto Leave「On」\n"
                else: md+="〠Auto Leave「Off」\n"
                if wait["timeline"] == True: md+="〠Share「On」\n"
                else:md+="〠Share「Off」\n"
                if wait["autoAdd"] == True: md+="〠Auto Add「On」\n"
                else:md+="〠Auto Add「Off」\n"
                if wait["commentOn"] == True: md+="〠Comment「On」\n"
                else:md+="〠Comment「Off」\n𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓\n ⭐ᖫ✧ᵐ.ʳ✧ᖭ ᵇᵒᵗ⭐  \n𖤓≛≛≛≛≛≛≛≛≛≛≛≛≛𖤓"
                cl.sendText(msg.to,md)
            elif msg.text in ["Group id","Ginfo"]:
                gid = cl.getGroupIdsJoined()
                h = ""
                for i in gid:
                    h += "[%s]:\n%s\n" % (cl.getGroup(i).name,i)
                cl.sendText(msg.to,h)
            elif msg.text in ["Cancelall"]:
              #if msg.from_ in admin:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been refused")
                else:
                    cl.sendText(msg.to,"æ‹’ç»�äº†å…¨éƒ¨çš„é‚€è¯·ã€‚")
            elif "album removeat’" in msg.text:
                gid = msg.text.replace("album removeat’","")
                albums = cl.getAlbum(gid)["result"]["items"]
                i = 0
                if albums != []:
                    for album in albums:
                        cl.deleteAlbum(gid,album["id"])
                        i += 1
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,str(i) + "Albums deleted")
                else:
                    cl.sendText(msg.to,str(i) + "åˆ é™¤äº†äº‹çš„ç›¸å†Œã€‚")
            elif msg.text in ["è‡ªå‹•è¿½åŠ :ã‚ªãƒ³","Add on","Auto add:on","è‡ªå‹•è¿½åŠ ï¼šé–‹"]:
              #if msg.from_ in admin:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"Done")
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["è‡ªå‹•è¿½åŠ :ã‚ªãƒ•","Add off","Auto add:off","è‡ªå‹•è¿½åŠ ï¼šé—œ"]:
              #if msg.from_ in admin:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
            elif "Message change: " in msg.text:
                wait["message"] = msg.text.replace("Message change: ","")
                cl.sendText(msg.to,"message changed")
            elif "Message add: " in msg.text:
                wait["message"] = msg.text.replace("Message add: ","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed")
                else:
                    cl.sendText(msg.to,"doneã€‚")
            elif msg.text in ["Message","è‡ªå‹•è¿½åŠ å•�å€™èªžç¢ºèª�"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message change to\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as followsã€‚\n\n" + wait["message"])
            elif "Comment:" in msg.text:
                c = msg.text.replace("Comment:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"message changed")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif "Add comment:" in msg.text:
                c = msg.text.replace("Add comment:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
#---------------------Sc invite owner ke group------
            elif "/invitemeto: " in msg.text:
              #if msg.from_ in admin:
                gid = msg.text.replace("/invitemeto: ","")
                if gid == "":
                  ki.sendText(msg.to,"Invalid group id")
                else:
                  try:
                    ki.findAndAddContactsByMid(msg.from_)
                    ki.inviteIntoGroup(gid,[msg.from_])
                  except:
                    ki.sendText(msg.to,"Mungkin saya tidak di dalaam grup itu")
#--------===---====--------------
            elif msg.text in ["ã‚³ãƒ¡ãƒ³ãƒˆ:ã‚ªãƒ³","Comment on","Comment:on","è‡ªå‹•é¦–é �ç•™è¨€ï¼šé–‹"]:
              #if msg.from_ in admin:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already on")
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["ã‚³ãƒ¡ãƒ³ãƒˆ:ã‚ªãƒ•","Comment off","comment off","è‡ªå‹•é¦–é �ç•™è¨€ï¼šé—œ"]:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already off")
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
            elif msg.text in ["Comment","ç•™è¨€ç¢ºèª�"]:
                cl.sendText(msg.to,"message changed to\n\n" + str(wait["comment"]))
            elif msg.text in ["Link"]:
                if msg.toType == 2:
                    x = cl.getGroup(msg.to)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        cl.updateGroup(x)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"line://ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can't be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Mr1 link"]:
                if msg.toType == 2:
                    x = cl.getGroup(msg.to)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        ki.updateGroup(x)
                    gurl = ki.reissueGroupTicket(msg.to)
                    ki.sendText(msg.to,"line://ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can't be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Mr2 link"]:
                if msg.toType == 2:
                    x = cl.getGroup(msg.to)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        ki2.updateGroup(x)
                    gurl = ki2.reissueGroupTicket(msg.to)
                    ki2.sendText(msg.to,"line://ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can't be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Comment bl "]:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wl "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)
#======================================================# 
            elif "Setlast" in msg.text:
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                print "Setlastpoint"

            elif "Viewlast" in msg.text:
	        lurkGroup = ""
	        dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%d日 %H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        grp = '\n  • '.join(str(f) for f in dataResult)
                        total = '\nThese %iuesrs have seen at the lastseen point(｀・ω・´)\n\n%s' % (len(dataResult), datetime.now().strftime('%H:%M:%S') )
                        cl.sendText(msg.to, "  • %s %s" % (grp, total))
                    else:
                        cl.sendText(msg.to, "KAGA ADA SIDERR!!!\nTOLOL!!!!!\nATO LU GA KETIK SETLASTPOINT DULU GOBLOK!!!!!")
                    print "Viewlastseen"
#======================================================# 
            elif msg.text in ["Cek"]:
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                try:
                  del wait2['readPoint'][msg.to]
                  del wait2['readMember'][msg.to]
                except:
	            pass
                now2 = datetime.now()
                wait2['readPoint'][msg.to] = msg.id
                wait2['readMember'][msg.to] = ""
                wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                wait2['ROM'][msg.to] = {}
                print wait2

            elif msg.text in ["Sider"]:
		  if msg.to in wait2['readPoint']:
	            if wait2["ROM"][msg.to].items() == []:
	              chiya = ""
	            else:
	              chiya = ""
	              for rom in wait2["ROM"][msg.to].items():
	                print rom
	                chiya += rom[1] + "\n"

	            cl.sendText(msg.to, " %s\n\n◀◀◀◀⚫▶▶▶▶\n\n%s\n\nThese uesrs have seen at the lastseen\npoint(｀・ω・´)\n%s"  % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
	          else:
	            cl.sendText(msg.to, "Sider ga bisa di read cek setpoint dulu bego tinggal ketik\nSetlastpoint\nkalo mau liat sider ketik\nViewlastseen")
#======================================================#                     
        #-------------Fungsi Jam on/off Start-------------------#            
            elif msg.text in ["Jam on"]:
              #if msg.from_ in admin:
                if wait["clock"] == True:
                    cl.sendText(msg.to,"Done jam on")
                else:
                    wait["clock"] = True
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"(%H:%M)")
                    profile = ki.getProfile()
                    profile.displayName = wait["cName4"] + nowT
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"Jam Selalu On")
            elif msg.text in ["Jam off"]:
              #if msg.from_ in admin:
                if wait["clock"] == False:
                    cl.sendText(msg.to,"Done jam off")
                else:
                    wait["clock"] = False
                    cl.sendText(msg.to,"Jam Sedang Off")
        #-------------Fungsi Jam on/off Finish-------------------#           
         
        #-------------Fungsi Change Clock Start------------------#
            elif msg.text in ["Change clock"]:
                n = msg.text.replace("Change clock","")
                if len(n.decode("utf-8")) > 13:
                    cl.sendText(msg.to,"changed")
                else:
                    wait["cName"] = n
                    cl.sendText(msg.to,"changed to\n\n" + n)
        #-------------Fungsi Change Clock Finish-----------------#           
        
         #-------------Fungsi Jam Update Start---------------------#            
            elif msg.text in ["Jam Update"]:
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"(%H:%M)")
                    profile = ki.getProfile()
                    profile.displayName = wait["cName4"] + nowT
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"Sukses update")
                else:
                    ki.sendText(msg.to,"Aktifkan jam terlebih dulu")
        #-------------Fungsi Jam Update Finish-------------------#

            elif msg.text == "Cek":
              #if msg.from_ in admin:
                cl.sendText(msg.to, "Cek the lastseens' point(｀・ω・´)\n「DONE」")
                try:
                  del wait2['readPoint'][msg.to]
                  del wait2['readMember'][msg.to]
                except:
                  pass
                now2 = datetime.now()
                wait2['readPoint'][msg.to] = msg.id
                wait2['readMember'][msg.to] = ""
                wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
                wait2['ROM'][msg.to] = {}
                #print wait2
              
            elif msg.text == "Ctv":
                 #if msg.from_ in admin:
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print rom
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to, "🔎 PROTECT SIDER 🔍 %s\n\n💮 LIST SIDER 💮\n%s\n\nReading point creation date n time:\n[%s]"  % (wait['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        cl.sendText(msg.to, "Untuk memulai awal silahkan ketik \n「Cek」")
#-----------------------------------------------

#-----------------------------------------------
         #----------------Fungsi Join Group Start-----------------------#
            elif msg.text in ["Masuk","Join all","Gass"]:
              #if msg.from_ in owner or admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.001)
                        ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.001)
                        ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.001)
                        ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.001)
                        ki5.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.001)
                        H = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        H.preventJoinByTicket = True
                        cl.updateGroup(H)
                        print "Semua Sudah Lengkap"
    #----------------------Fungsi Join Group Finish---------------#

    #-------------Fungsi Leave Group Start---------------#
            elif msg.text in ["Cabut","Keluar","Kabur","Cuss"]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                  cl.getGroup(msg.to)
                  ki.leaveGroup(msg.to)
                  ki2.leaveGroup(msg.to)
                  ki3.leaveGroup(msg.to)
                  ki4.leaveGroup(msg.to)
                  ki5.leaveGroup(msg.to)
    #-------------Fungsi Leave Group Finish---------------#
    
    #-------------Fungsi Tag All Start---------------#
            elif msg.text in ["Tagall","Tegall","Oii"]:
            	 if msg.from_ in admin:
                  group = cl.getGroup(msg.to)
                  nama = [contact.mid for contact in group.members]

                  cb = ""
                  cb2 = ""
                  strt = int(0)
                  akh = int(0)
                  for md in nama:
                      akh = akh + int(6)

                      cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""

                      strt = strt + int(7)
                      akh = akh + 1
                      cb2 += "@nrik \n"

                  cb = (cb[:int(len(cb)-1)])
                  msg.contentType = 0
                  msg.text = cb2
                  msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}

                  try:
                      cl.sendMessage(msg)
                  except Exception as error:
                    print error
    #-------------Fungsi Tag All Finish---------------#
    #-------------Tag All Test------------------------#
    #-------------------------------------------------#
            elif msg.text in ["Bot Like","Like me","Bot like"]:
              #if msg.from_ in admin:
                print "[Command]Like executed"
                cl.sendText(msg.to,"Done BossQu")
                try:
                  likePost()
                except:
                  pass
                
            elif msg.text in ["Like temen","Like","Bot like temen"]:
              #if msg.from_ in admin:
                print "[Command]Like executed"
                cl.sendText(msg.to,"Done BossQu")
                try:
                  autolike()
                except:
                  pass
        #----------------Fungsi Banned Kick Target Start-----------------------#
            elif msg.text in ["Kill "]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    group = random.choice(KAC).getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        random.choice(KAC).sendText(msg.to,"Selamat tinggal")
                        random.choice(KAC).sendText(msg.to,"Jangan masuk lagi􀨁􀆷devil smile􏿿")
                        return
                    for jj in matched_list:
                        try:
                            klist=[ki,ki2,ki3,ki4,ki5]
                            kicker=random.choice(klist)
                            kicker.kickoutFromGroup(msg.to,[jj])
                            print (msg.to,[jj])
                        except:
                            pass
        #----------------Fungsi Banned Kick Target Finish----------------------#   
        #------------ Copy & Backup -------------#
            elif msg.text in ["Backup","backup"]:
              try:
                cl.updateDisplayPicture(backup.pictureStatus)
                cl.updateProfile(backup)
                cl.sendText(msg.to,"Backup done")
              except Exception as e:
                cl.sendText(msg.to, str (e))
                
            elif msg.text in ["Mr1 Backup","Mr1 backup"]:
              try:
                ki.updateDisplayPicture(backup.pictureStatus)
                ki.updateProfile(backup)
                ki.sendText(msg.to,"Backup done")
              except Exception as e:
                ki.sendText(msg.to, str (e))

            elif msg.text in ["Mr2 Backup","Mr2 backup"]:
              try:
                ki2.updateDisplayPicture(backup.pictureStatus)
                ki2.updateProfile(backup)
                ki2.sendText(msg.to,"Backup done")
              except Exception as e:
                ki2.sendText(msg.to, str (e))

            elif msg.text in ["Mr3 Backup","Mr3 backup"]:
              try:
                ki3.updateDisplayPicture(backup.pictureStatus)
                ki3.updateProfile(backup)
                ki3.sendText(msg.to,"Backup done")
              except Exception as e:
                ki3.sendText(msg.to, str (e))

            elif msg.text in ["Mr4 Backup","Mr4 backup"]:
              try:
                ki4.updateDisplayPicture(backup.pictureStatus)
                ki4.updateProfile(backup)
                ki4.sendText(msg.to,"Backup done")
              except Exception as e:
                ki4.sendText(msg.to, str (e))

            elif msg.text in ["Mr5 Backup","Mr5 backup"]:
              try:
                ki5.updateDisplayPicture(backup.pictureStatus)
                ki5.updateProfile(backup)
                ki5.sendText(msg.to,"Backup done")
              except Exception as e:
                ki5.sendText(msg.to, str (e))


            elif "Copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Copy @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  cl.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      cl.CloneContactProfile(target)
                      cl.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr1 copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr1 copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki.CloneContactProfile(target)
                      ki.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr2 copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr2 copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki2.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki2.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki2.CloneContactProfile(target)
                      ki2.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr3 copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr3 copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki3.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki3.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki3.CloneContactProfile(target)
                      ki3.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr4 copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr4 copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki4.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki4.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki4.CloneContactProfile(target)
                      ki4.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr5 copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr5 copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki5.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki5.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki5.CloneContactProfile(target)
                      ki5.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
            elif "Mr copy @" in msg.text:
              if msg.toType == 2:
                print"[Copy]"
                _name = msg.text.replace("Mr copy @","")
                _nametarget = _name.rstrip(' ')
                gs = ki.getGroup(msg.to)
                gs = ki2.getGroup(msg.to)
                gs = ki3.getGroup(msg.to)
                gs = ki4.getGroup(msg.to)
                gs = ki5.getGroup(msg.to)
                targets=[]
                for g in gs.members:
                  if _nametarget == g.displayName:
                    targets.append(g.mid)
                if targets == []:
                  ki.sendText(msg.to,"Not Found")
                  ki2.sendText(msg.to,"Not Found")
                  ki3.sendText(msg.to,"Not Found")
                  ki4.sendText(msg.to,"Not Found")
                  ki5.sendText(msg.to,"Not Found")
                else:
                  for target in targets:
                    try:
                      ki.CloneContactProfile(target)
                      ki.sendText(msg.to,"Success Copy")
                      ki2.CloneContactProfile(target)
                      ki2.sendText(msg.to,"Success Copy")
                      ki3.CloneContactProfile(target)
                      ki3.sendText(msg.to,"Success Copy")
                      ki4.CloneContactProfile(target)
                      ki4.sendText(msg.to,"Success Copy")
                      ki5.CloneContactProfile(target)
                      ki5.sendText(msg.to,"Success Copy")
                    except Exception as e:
                      print e
#--------------------------------------------------------------------------------
            elif ("Cover " in msg.text):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            cu = cl.channel.getCover(target)
                            path = str(cu)
                            cl.sendText(msg.to,"Cover " + contact.displayName)
                            cl.sendImageWithURL(msg.to,path)
                        except Exception as error:
                            print error
#------------------------------------------------------------------
            elif ("Pic " in msg.text):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                            cl.sendImageWithURL(msg.to,image)
                        except Exception as error:
                            print error
#===============================================================================#
            elif msg.text in ["Steal"]:
                wait["stealcontact"] = True
                cl.sendText(msg.to,"Send Contact")
#===============================================================================#
            elif "Pict group " in msg.text:
            	try:
                     saya = msg.text.replace("Pict group ","")
                     gid = cl.getGroupIdsJoined()
                     for i in gid:
                         h = cl.getGroup(i).name
                         gna = cl.getGroup(i)
                         if h == saya:
                             cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+ gna.pictureStatus)       
                except Exception as error:
                 	print error
#======================================================#
            elif "Image " in msg.text:
                search = msg.text.replace("Image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                print path
                try:
                    cl.sendText(msg.to,"Waiting...")
                    cl.sendImageWithURL(msg.to,path)
                    print "Image Terkirim"
                except Exception as error:
                    print error 
#======================================================#
            elif msg.text in ["Sepi","sepi","Pada kemana","Hening","pada kemana","Pada kemana?","Krik","krik"]:
            	   cat = ["http://dl.profile.line-cdn.net/0ht807OOssKxcNTgdBn9NUQDELJXp6YC1fdSs0eS5OJ3IpfWwTNHtgci8cJXMhd2xGNC1lIXwZdHd1"]
                   meow = random.choice(cat)
                   cl.sendImageWithURL(msg.to,meow)
                   
            elif msg.text in ["Wow","wow","Wew","wew"]:
            	   cat = ["https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQL7wVB5uZjcsk2jRNnUlZ_hAYBoOmegYs2TVSPvWh2u0rMWtsKAw0HNmIT"]
                   meow = random.choice(cat)
                   cl.sendImageWithURL(msg.to,meow)
            elif msg.text in ["Njir","Sue lu","Njer","Pea","Sue","Gblk","Goblok","Tolol","Pekok","pekok","dasar","sue","Bah","bah"]:
                   njir = ["https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQxICnVetGdpNGqPvszVVGZOZiT2O_BumB-rfAu2nb_5phfY-aW"]
                   wkwk = random.choice(njir)
                   cl.sendImageWithURL(msg.to,wkwk)
             #      https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0xwLFnruyt2TCv6YU0W2YX9W4A_KeEqlSX52j2VgnmQ6hmxcqV_8RgOiw_g
            elif "@🔸Remシールド " in msg.text:
                  if wait["ResponTag"] == True:
                    sayang = ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRF-OR-cB0IMdTuuU3vMEK2zohb0xKBc2c1xQBuHz2aLaaLQGy7LKrqulFMtA","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQ5gcWibso9KhGmolteN9wJ7mlz5aj_OfMNzS1xM4p4MmXwTFCkesY0lQhfg"]
                    cinta = random.choice(sayang)
                    cl.sendImageWithURL(msg.to,cinta)
                    jodoh =["Ada apa kak?","Cie ngetag","Aku Bot kak ga usah di tag:v"]
                    pasangan = random.choice(jodoh)
                    cl.sendText(msg.to,pasangan)
                    
            elif "@ 🔸Mikuシールド  " in msg.text:
                  if wait["ResponTag"] == True:
                    sayang = ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0xwLFnruyt2TCv6YU0W2YX9W4A_KeEqlSX52j2VgnmQ6hmxcqV_8RgOiw_g"]
                    cinta = random.choice(sayang)
                    cl.sendImageWithURL(msg.to,cinta)
                    cl.sendText(msg.to,"Hadir....")
                    
            elif "@🔸Emiliaシールド  " in msg.text:
                  if wait["ResponTag"] == True:
                    sayang = ["Cie ngetag","Tersummon","Iya kak?","Kenapa?","Akhirnya di tag juga sama doi:v"]
                    cinta = random.choice(sayang)
                    cl.sendText(msg.to,cinta)
              
#-------------Fungsi Tag 2 Start---------------#
            elif msg.text in ["Arespon on"]:
                if wait["detectMention"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᴬᶜᵗⁱᵛᵉᵈ")
                    else:
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᴬᶜᵗⁱᵛᵉᵈ")
                else:
                   wait["detectMention"] = True
                if wait["detectMention"] == "JP":
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᴬᶜᵗⁱᵛᵉᵈ")
                else:
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᴬᶜᵗⁱᵛᵉᵈ")
            elif msg.text in ["Arespon off"]:
                if wait["detectMention"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᵁⁿᵃᶜᵗⁱᵛᵉᵈ")
                    else:
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᵁⁿᵃᶜᵗⁱᵛᵉᵈ")
                else:
                    wait["detectMention"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᵁⁿᵃᶜᵗⁱᵛᵉᵈ")
                    else:
                        cl.sendText(msg.to,"[ ᴬ̲ᵘ̲ᵗ̲ᵒ̲ ᴿ̲ᵉ̲ˢ̲ᵖ̲ᵒ̲ⁿ̲ᵈ̲ ]\n✔ ᵁⁿᵃᶜᵗⁱᵛᵉᵈ")

            elif "Instagram " in msg.text:
                    try:
                    	instagram = msg.text.replace("Instagram ","")
                        response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                        data = response.json()
                        namaIG = str(data['user']['full_name'])
                        bioIG = str(data['user']['biography'])
                        mediaIG = str(data['user']['media']['count'])
                        verifIG = str(data['user']['is_verified'])
                        usernameIG = str(data['user']['username'])
                        followerIG = str(data['user']['followed_by']['count'])
                        profileIG = data['user']['profile_pic_url_hd']
                        privateIG = str(data['user']['is_private'])
                        followIG = str(data['user']['follows']['count'])
                        text = "Name : "+namaIG+"\nBiography :\n"+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nMedia : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"\nUsername : "+usernameIG+""
                        cl.sendImageWithURL(msg.to, profileIG)
                        cl.sendText(msg.to, str(text))
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
            
#======================================================#
            elif "Tr id@en:" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'en'
                kata = msg.text.replace("Translate id@en:","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"[•======FROM ID======•]\n" + "" + kata + "\n[•======FROM EN======•]\n" + "" + result) 
#======================================================#
            elif "Tr en@id:" in msg.text:
                bahasa_awal = 'en'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Translate en@id:","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"[•======FROM EN======•]\n" + "" + kata + "\n[•======FROM ID======•]\n" + "" + result)
#======================================================#
            elif "Tr id@ja:" in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'ja'
                kata = msg.text.replace("Translate id@ja:","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"[•======FROM ID======•]\n" + "" + kata + "\n[•======FROM JA======•]\n" + "" + result)
#======================================================#
            elif "Tr ja@id:" in msg.text:
                bahasa_awal = 'ja'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Translate ja@id:","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"[•======FROM JA======•]\n" + "" + kata + "\n[•======FROM ID======•]\n" + "" + result)
##########Kalau gak suka instal module translate atau sejenisnya
#========================================================
            elif "Text: " in msg.text:
                txt = msg.text.replace("Text: ", "")
                cl.kedapkedip(msg.to,txt)
                print "[Command] Kedapkedip"                        
#========================================================
#-----------------------------------------------
            elif "Vn " in msg.text:
                 psn = msg.text.replace("Vn ","")
                 tts = gTTS(psn, lang='id', slow=False)
                 tts.save('tts.mp3')
                 cl.sendAudio(msg.to, 'tts.mp3')
#-----------------------------------------------
            elif "VnJa " in msg.text:
                 psn = msg.text.replace("VnJa ","")
                 tts = gTTS(psn, lang='ja', slow=False)
                 tts.save('tts.mp3')
                 cl.sendAudio(msg.to, 'tts.mp3')
#Tau work apa kagak (haha) kalau ada yg salah koreksi yah

#Cara pemakaian Say@Negara: text
#------------------------------------------------------------------
            elif ("Music " in msg.text):
                songname = msg.text.replace("Music ","")
                params = {"songname": songname}
                r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    abc = song[3].replace('https://','http://')
                    cl.sendText(msg.to, "Judul: " + song[0].encode('utf-8') +"" + "\n" + "Durasi: " + song[1].encode('utf-8') +"" + "\n" + "Link: " + song[4].encode('utf-8'))
                    cl.sendText(msg.to, "Tunggu Bentar....")
                    cl.sendAudioWithURL(msg.to, abc)

            elif 'cmusic ' in msg.text.lower():
#                          if msg.from_ in admin:
                            try:
                                songname = msg.text.lower().replace('cmusic ','')
                                params = {'songname': songname}
                                r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                                data = r.text
                                data = json.loads(data)
                                for song in data:
                                    hasil = 'This is Your Music\n'
                                    hasil += 'Judul : ' + song[0]
                                    hasil += '\nDurasi : ' + song[1]
                                    hasil += '\nLink Download : ' + song[4]
                                    hasil += '\nLirik :\n ' + song[5]
                                    cl.sendText(msg.to, hasil)
                                    cl.sendText(msg.to, "Please Wait for audio...")
                                    cl.sendAudioWithURL(msg.to, song[3])
                            except Exception as njer:
                                    cl.sendText(msg.to, str(njer))                    
#------------------------------------------------------------------
            elif ("Rem music " in msg.text):
                try:
                    songname = msg.text.replace("Music ","")
                    params = {"songname": songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        abc = song[3].replace('https://','http://')
                        kk.sendText(msg.to, "Judul: " + song[0].encode('utf-8') +"" + "\n" + "Durasi: " + song[1].encode('utf-8') +"" + "\n" + "Link: " + song[4].encode('utf-8'))
                        kk.sendText(msg.to, "Tunggu Bentar....")
                        kk.sendAudioWithURL(msg.to, abc)
                except Exception as error:
                  print error
            elif "Lyric " in msg.text:
                songname = msg.text.replace("Lyric ","")
                params = {"songname": songname}
                r=requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data=r.text
                data=json.loads(data)
                for song in data:
                    songz = song[5].encode('utf-8')
                    lyric = songz.replace('ti:','Judul - ')
                    lyric = lyric.replace('ar:','Artis - ')
                    lyric = lyric.replace('al:','Album - ')
                    lyric = lyric.replace('by:','')
                    removeString = "[1234567890.:]"
                    for char in removeString:
                        lyric = lyric.replace(char,'')
                    cl.sendText(msg.to,lyric)
                    
            elif "Rem lirik " in msg.text:
                songname = msg.text.replace("Getlirik ","")
                params = {"songname": songname}
                r=requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data=r.text
                data=json.loads(data)
                for song in data:
                    songz = song[5].encode('utf-8')
                    lyric = songz.replace('ti:','Judul - ')
                    lyric = lyric.replace('ar:','Artis - ')
                    lyric = lyric.replace('al:','Album - ')
                    lyric = lyric.replace('by:','')
                    removeString = "[1234567890.:]"
                    for char in removeString:
                        lyric = lyric.replace(char,'')
                    kk.sendText(msg.to,lyric)
#======================================================# 
            elif "#Ytube " in msg.text.lower():
                   query = msg.text.replace("Youtube ","")
                   try:
                       if len(query) == 3:
                           isi = yt(query[2])
                           hasil = isi[int(query[1])-1]
                           print hasil
                           cl.sendText(msg.to, "Tunggu Bentar....")
                           cl.sendText(msg.to,hasil)
                       else:
                           isi = yt(query[1])
                           print isi
                           cl.sendText(msg.to,isi[0])
                   except Exception as error:
                           print error
            elif 'Ytube ' in msg.text:
                try:
                    textToSearch = (msg.text).replace('Ytube ', "").strip()
                    query = urllib.quote(textToSearch)
                    url = "https://www.youtube.com/results?search_query=" + query
                    response = urllib2.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    path = 'https://www.youtube.com' + results['href']
                    cl.sendText(msg.to,'https://www.youtube.com' + results['href'])
                    cl.sendText(msg.to,"Wait To Send Video")
                    cl.sendVideoWithURL(msg.to, path)
                except Exception as e:
                	 cl.sendText(msg.to, str(e))
            elif "Video " in msg.text:
                try:
                    search = msg.text.replace("Vidio ","")
                    query = urllib.quote(search)
                    url = 'https://www.youtube.com/results?search_query=' + query
                    response = urllib2.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    path = 'https://www.youtube.com' + results['href']
                    print path
                    cl.sendText(msg.to, "Tunggu Bentar...")
                    cl.sendVideoWithURL(msg.to, path)
                except Exception as e:
                    cl.sendText(msg.to, str(e))
#======================================================#
        #-----------------------------------------
            elif "GassPoul" in msg.text:
              if msg.from_ in owner:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("GassPoul","")
                    gs = cl.getGroup(msg.to)
#                    gs = ki.getGroup(msg.to)
#                    gs = ki2.getGroup(msg.to)
#                    gs = ki3.getGroup(msg.to)
#                    gs = ki4.getGroup(msg.to)
#                    gs = ki5.getGroup(msg.to)
                    cl.sendText(msg.to,"3")
                    cl.sendText(msg.to,"2")
                    cl.sendText(msg.to,"1")
                    #msg.contentType = 13
                    #msg.contentMetadata = {'mid': 'u33e3541670221ae9162f59188339b2ec'}
                    cl.sendMessage(msg)
                    cl.sendText(msg.to,"This is Game")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                          if target not in Bots or owner:
                            if target in owner:
                              pass
                            elif target in admin:
                              pass
                            elif target in Bots:
                              pass
                            else:
                              try:
                                klist=[cl]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                                print (msg.to,[g.mid])
                              except:
                                random.choice(KAC).kickoutFromGroup(msg.to,[target])
        #----------------Fungsi Kick User Target Start----------------------#
            elif "Nk " in msg.text:
              if msg.from_ in admin:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"] [0] ["M"]
                for x in key["MENTIONEES"]:
                  targets.append(x["M"])
                for target in targets:
                  try:
                    cl.kickoutFromGroup(msg.to,[target])
                  except:
                    cl.sendText(msg.to,"Error")
        #----------------Fungsi Kick User Target Finish----------------------#      
            elif "Blacklist @ " in msg.text:
              #if msg.from_ in admin:
                _name = msg.text.replace("Blacklist @ ","")
                _kicktarget = _name.rstrip(' ')
                cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _kicktarget == g.displayName:
                        targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,"Not found")
                        else:
                            for target in targets:
                                try:
                                    wait["blacklist"][target] = True
                                    f=codecs.open('st2__b.json','w','utf-8')
                                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendText(msg.to,"Succes Plak")
                                except:
                                    cl.sendText(msg.to,"error")
            
            #----------------Fungsi Banned User Target Start-----------------------#
            elif "Ban @" in msg.text:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Banned] Sukses"
                    _name = msg.text.replace("Ban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = ki2.getGroup(msg.to)
                    gs = ki3.getGroup(msg.to)
                    gs = ki4.getGroup(msg.to)
                    gs = ki5.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Dilarang Banned Bot")
                        ki.sendText(msg.to,"Dilarang Banned Bot")
                        ki2.sendText(msg.to,"Dilarang Banned Bot")
                        ki3.sendText(msg.to,"Dilarang Banned Bot")
                        ki4.sendText(msg.to,"Dilarang Banned Bot")
                        ki5.sendText(msg.to,"Dilarang Banned Bot")
                    else:
                        for target in targets:
                            try:
                                wait["blacklist"][target] = True
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Akun telah sukses di banned")
                            except:
                                cl.sendText(msg.to,"Error")
            #----------------Fungsi Banned User Target Finish-----------------------# 
            #----------------Mid via Tag--------------
            elif "Mid @" in msg.text:
              #if msg.from_ in admin:
                _name = msg.text.replace("Mid @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        cl.sendText(msg.to, g.mid)
                    else:
                        pass
            #-----------------------------------------
    	    elif ("Kado" in msg.text):
              if msg.from_ in owner:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                	    msg.contentType = 9
                            msg.contentMetadata={'PRDID': '89131c1a-e549-4bd5-9e60-e24de0d2e252',
                                        'PRDTYPE': 'THEME',
                                        'MSGTPL': '6'}
                            msg.text = None
                            cl.sendMessage(msg)
                            cl.sendMessage(msg,target)
                        except:
			       cl.sendText(msg.to,"Udah di gift, bilangnya apa kak?")
            #----------------Fungsi Unbanned User Target Start-----------------------#
            elif "Unban @" in msg.text:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Unban] Sukses"
                    _name = msg.text.replace("Unban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
#                    gs = ki.getGroup(msg.to)
#                    gs = ki2.getGroup(msg.to)
#                    gs = ki3.getGroup(msg.to)
#                    gs = ki4.getGroup(msg.to)
#                    gs = ki5.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Tidak Ditemukan.....")
#                        ki.sendText(msg.to,"Tidak Ditemukan.....")
#                        ki2.sendText(msg.to,"Tidak Ditemukan.....")
#                        ki3.sendText(msg.to,"Tidak Ditemukan.....")
#                        ki4.sendText(msg.to,"Tidak Ditemukan.....")
#                        ki5.sendText(msg.to,"Tidak Ditemukan.....")
                    else:
                        for target in targets:
                            try:
                                del wait["blacklist"][target]
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Akun Bersih Kembali")
                            except:
                                cl.sendText(msg.to,"Error")
          #----------------Fungsi Unbanned User Target Finish-----------------------#
           
        #-------------Fungsi Spam Start---------------------#
            elif msg.text in ["Up","up","Up Chat","Up chat","up chat","Upchat","upchat"]:
              #if msg.from_ in admin:
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
                cl.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki2.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki2.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki2.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki2.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki2.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki3.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki4.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
#                ki5.sendText(msg.to,"P 􀔃􀆶squared up!􏿿")
        #-------------Fungsi Spam Finish---------------------#

        #-------------Fungsi Broadcast Start------------#
            elif "Bc " in msg.text:
              #if msg.from_ in admin:
                bctxt = msg.text.replace("Bc ","")
                a = cl.getGroupIdsJoined()
                for taf in a:
                  cl.sendText(taf, (bctxt))
      #--------------Fungsi Broadcast Finish-----------#

            elif msg.text in ["LG"]:
              #if msg.from_ in admin:
                gids = cl.getGroupIdsJoined()
                h = ""
                for i in gids:
                  #####gn = cl.getGroup(i).name
                  h += "〠%s Member\n" % (cl.getGroup(i).name   +"👉"+str(len(cl.getGroup(i).members)))
                  cl.sendText(msg.to,"=======╠List Group╣======\n"+ h +"Total Group :"+str(len(gids)))
                
            elif msg.text in ["LG2"]:
              #if msg.from_ in admin:
                gids = cl.getGroupIdsJoined()
                h = ""
                for i in gids:
                    h += "〠[%s]:%s\n" % (cl.getGroup(i).name,i)
                cl.sendText(msg.to,h+"Total Group :"+str(len(gids)))
      #--------------List Group------------
#==============================================================================
            if msg.contentType == 13:
                if wait["stealcontact"] == True:
                        _name = msg.contentMetadata["displayName"]
                        copy = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                print "[Target] Stealed"
                                break                             
                            else:
                                targets.append(copy)

#======================================================# 
                elif wait["Pc"] == True:
                    if msg.from_ in admin:
                        _name = msg.contentMetadata["displayName"]
                        pc = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        teks = wait["pm"]
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                print "[Target] Personal Message"
                                break                             
                            else:
                                targets.append(pc)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    cl.sendText(target,teks+"\n\n\nHm....")
                                    cl.sendText(msg.to,"Pesan telah dikirim ke " + _name)
                                    wait["pc"] = False
                                    break
                                except:
                                    pass
#======================================================# 
       #------------ Keluar Dari Semua Group------
            elif msg.text in ["Bot out","Mr bye"]:
              #if msg.from_ in admin:
                gid = cl.getGroupIdsJoined()
                gid = ki.getGroupIdsJoined()
                gid = ki2.getGroupIdsJoined()
                gid = ki3.getGroupIdsJoined()
                gid = ki4.getGroupIdsJoined()
                gid = ki5.getGroupIdsJoined()
                for i in gid:
                  ki.leaveGroup(i)
                  ki2.leaveGroup(i)
                  ki3.leaveGroup(i)
                  ki4.leaveGroup(i)
                  ki5.leaveGroup(i)
                if wait["lang"] == "JP":
                  cl.sendText(msg.to,"Semua Sukses Keluar Boss")
                else:
                  cl.sendText(msg.to,"He declined all invitations")
#------------------------End---------------------

 #-----------------End-----------
            elif msg.text in ["Mr katakan hi"]:
                ki.sendText(msg.to,"Hi buddy 􀜁􀅔Har Har􏿿")
                ki2.sendText(msg.to,"Hi buddy 􀜁􀅔Har Har􏿿")
                ki3.sendText(msg.to,"Hi buddy 􀜁􀅔Har Har􏿿")

#-----------------------------------------------
            elif msg.text in ["Welcome"]:
                ki.sendText(msg.to,"Selamat datang di Group Kami")
                ki.sendText(msg.to,"Jangan nakal ok!")
#-----------------------------------------------
            elif msg.text in ["PING","Ping","ping"]:
                ki.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ki2.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ki3.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
#-----------------------------------------------

       #-------------Fungsi Respon Start---------------------#
            elif msg.text in ["Absen","Absen bot","Absen dulu","Respon"]:
              #if msg.from_ in admin:
                cl.sendText(msg.to,"On")
                ki.sendText(msg.to,"Siji")
                ki2.sendText(msg.to,"Loro")
                ki3.sendText(msg.to,"Telu")
                ki4.sendText(msg.to,"Papat")
                ki5.sendText(msg.to,"Lima")
                ki2.sendText(msg.to,"Done Wes Pass BosQu")
      #-------------Fungsi Respon Finish---------------------#

#------------------------------------------------------------------	
            elif "Steal home @" in msg.text:            
                print "[Command]dp executing"
                _name = msg.text.replace("Steal home @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                    ki.sendText(msg.to,"Contact not found")
                else:
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            cu = cl.channel.getCover(target)
                            path = str(cu)
                            cl.sendImageWithURL(msg.to, path)
                        except:
                            pass
                print "[Command]dp executed"			
#------------------------------------------------------------------
            elif "Steal dp @" in msg.text:            
                print "[Command]dp executing"
                _name = msg.text.replace("Steal dp @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                    ki.sendText(msg.to,"Contact not found")
                else:
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            cl.sendImageWithURL(msg.to, path)
                        except:
                            pass
                print "[Command]dp executed"			
 #------------------------------------------------------------------                            

      #-------------Fungsi Balesan Respon Start---------------------#
            elif msg.text in ["Ini Apa","ini apa","Apaan Ini","apaan ini"]:
                ki.sendText(msg.to,"Ya gitu deh intinya mah 􀨁􀅴questioning􏿿")

      #-------------Fungsi Balesan Respon Finish---------------------#

       #-------------Fungsi Speedbot Start---------------------#
            elif msg.text in ["Speed","Sp","Xp"]:
              #if msg.from_ in admin and owner:
                start = time.time()
                cl.sendText(msg.to, "Wait...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sDetik" % (elapsed_time))
      #-------------Fungsi Speedbot Finish---------------------#
#--------------------------------------------------------------#
#Cara pake (Spam on/off <100> hai)
            elif "Spam " in msg.text:
                if msg.from_ in admin:
                   txt = msg.text.split(" ")
                   jmlh = int(txt[2])
                   teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                   tulisan = jmlh * (teks+"\n")
                   if txt[1] == "on":
                        if jmlh <= 10000:
                             for x in range(jmlh):
                                   cl.sendText(msg.to, teks)
                        else:
                               cl.sendText(msg.to, "Ga bisa bego Kelewatan batas...! ")
                   elif txt[1] == "off":
                         if jmlh <= 10000:
                               cl.sendText(msg.to, tulisan)
                         else:
                               cl.sendText(msg.to, "Ehm...kelewatan batas bro...!")
#------------------------------------------------------------
            elif "Hay @" in msg.text:
                _name = msg.text.replace("Hay @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
##                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")  
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"Your Account Has Been Spammed !")
#                       ki.sendText(g.mid,"DONT BAPER KAKA")
#                       ki.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"LAFFYU MMMUACHH")
                       cl.sendText(g.mid,"DON'T BAPER KAKAKUH 😘")
                       cl.sendText(msg.to, "Done")
                       print " Spammed !"
      #-------------Fungsi Banned Send Contact Start------------------#
            elif msg.text in ["Ban"]:
              #if msg.from_ in admin:
                wait["wblacklist"] = True
                cl.sendText(msg.to,"Kirim contact")
                #ki.sendText(msg.to,"Kirim contact")
                #kk.sendText(msg.to,"Kirim contact")
                #kc.sendText(msg.to,"Kirim contact")
            elif msg.text in ["Unban"]:
              #if msg.from_ in admin:
                wait["dblacklist"] = True
                cl.sendText(msg.to,"Kirim contact")
                #ki.sendText(msg.to,"Kirim contact")
                #kk.sendText(msg.to,"Kirim contact")
                #kc.sendText(msg.to,"Kirim contact")
      #-------------Fungsi Banned Send Contact Finish------------------#
            elif msg.text in ["Creator"]:
#              cl.sendText(msg.to,"======================")
              msg.contentType = 13
              msg.contentMetadata = {'mid': 'u33e3541670221ae9162f59188339b2ec'}
              cl.sendMessage(msg)
              cl.sendText(msg.to,"======================")
              cl.sendText(msg.to,"Creator By ★ᖫ✧ᵐ.ʳ✧ᖭ ᵇᵒᵗ★")
                
      #-------------Fungsi Chat ----------------
#            elif msg.text in ["Woy","woy","Woi","woi","bot","Bot"]:
#                 quote = ['Istri yang baik itu Istri yang Mengizinkan Suaminya untuk Poligami 😂😂😂.','Kunci Untuk Bikin Suami Bahagia itu cuma satu..\nIzinkan Suamimu Untuk Selingkuh Coyyy ','Ah Kupret Lu','Muka Lu Kaya Jamban','Ada Orang kah disini?','Sange Euy','Ada Perawan Nganggur ga Coy?']
#                 psn = random.choice(quote)
#                 cl.sendText(msg.to,psn)
            
            elif "Say " in msg.text:
				bctxt = msg.text.replace("Say ","")
				cl.sendText(msg.to,(bctxt))
				ki2.sendText(msg.to,(bctxt))
				ki3.sendText(msg.to,(bctxt))
				ki4.sendText(msg.to,(bctxt))
				ki5.sendText(msg.to,(bctxt))
      #-------------Fungsi Bannlist Start------------------#          
            elif msg.text in ["Banlist"]:
              #if msg.from_ in admin:
                if wait["blacklist"] == {}:
                    random.choice(KAC).sendText(msg.to,"Tidak Ada Akun Terbanned")
                else:
                    random.choice(KAC).sendText(msg.to,"Blacklist user")
                    mc = ""
                    for mi_d in wait["blacklist"]:
                        mc += "->" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)
    #-------------Fungsi Bannlist Finish------------------#  
      
            elif msg.text in ["Cek ban"]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = ""
                    for mm in matched_list:
                        cocoa += mm + "\n"
                    cl.sendText(msg.to,cocoa + "")
            elif msg.text in ["Kill ban"]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"There was no blacklist user")
                        random.choice(KAC).sendText(msg.to,"There was no blacklist user")
                        random.choice(KAC).sendText(msg.to,"There was no blacklist user")
                        random.choice(KAC).sendText(msg.to,"There was no blacklist user")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        random.choice(KAC).kickoutFromGroup(msg.to,[jj])
                        random.choice(KAC).kickoutFromGroup(msg.to,[jj])
                        random.choice(KAC).kickoutFromGroup(msg.to,[jj])
                    cl.sendText(msg.to,"Blacklist emang pantas tuk di usir")
                    random.choice(KAC).sendText(msg.to,"Blacklist emang pantas tuk di usir")
                    random.choice(KAC).sendText(msg.to,"Blacklist emang pantas tuk di usir")
                    random.choice(KAC).sendText(msg.to,"Blacklist emang pantas tuk di usir")
            elif msg.text in ["Clear"]:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendText(msg.to,"I pretended to cancel and canceled.")
            elif "random: " in msg.text:
              #if msg.from_ in admin:
                if msg.toType == 2:
                    strnum = msg.text.replace("random: ","")
                    source_str = 'abcdefghijklmnopqrstuvwxyz1234567890@:;./_][!&%$#)(=~^|'
                    try:
                        num = int(strnum)
                        group = cl.getGroup(msg.to)
                        for var in range(0,num):
                            name = "".join([random.choice(source_str) for x in xrange(10)])
                            time.sleep(0.01)
                            group.name = name
                            cl.updateGroup(group)
                    except:
                        cl.sendText(msg.to,"Error")
            elif "albumat'" in msg.text:
                try:
                    albumtags = msg.text.replace("albumat'","")
                    gid = albumtags[:6]
                    name = albumtags.replace(albumtags[:34],"")
                    cl.createAlbum(gid,name)
                    cl.sendText(msg.to,name + "created an album")
                except:
                    cl.sendText(msg.to,"Error")
            elif "fakecat'" in msg.text:
                try:
                    source_str = 'abcdefghijklmnopqrstuvwxyz1234567890@:;./_][!&%$#)(=~^|'
                    name = "".join([random.choice(source_str) for x in xrange(10)])
                    anu = msg.text.replace("fakecat'","")
                    cl.sendText(msg.to,str(cl.channel.createAlbum(msg.to,name,anu)))
                except Exception as e:
                    try:
                        cl.sendText(msg.to,str(e))
                    except:
                        pass
#---------------------
        if op.type == 17:
          if op.param2 in Bots:
            return
          ginfo = cl.getGroup(op.param1)
          #cl.sendText(op.param1, "Selamat Datang Di Grup  " + ">>>" + str(ginfo.name) + "<<<" + "\n" + "Founder Grup " + str(ginfo.name) + " :\n" + ginfo.creator.displayName + "\n\n" + "Budayakan Baca Note !!! yah Ka 😊\nSemoga Betah Kk 😘")
          #cl.sendText(op.param1, "Founder Grup " + str(ginfo.name) + " :\n" + ginfo.creator.displayName)
          #cl.choice(KAC).sendText(op.param1,"Budayakan Baca Note !!! yah Ka 😊\nSemoga Betah Kk 😘")
          #print "MEMBER HAS JOIN THE GROUP"
#------------------------
#def poll message():
#  while True:
#    try:
        ops=poll.singleTrace(count=50)
        for op in ops:
            if op.type == OpType.RECEIVE_MESSAGE:
                msg = op.message
                if msg.text != None:
                    if msg.toType == 2:
                        may = cl.getProfile().mid
                        if may in str(msg.contentMetadata):
                            pilih = ['yang tag sy semoga jomblo seumur hidup','ngapain tag tag woe, kangen?','ada apa ini? ko di tag?','duhh kena tag, dianya kesepian kali yah','gk usah tag, gift tikel aja']
                            rslt = random.choice(pilih)
                            cl.sendText(msg.to, str(rslt))
                        else:
                            pass
                    else:
                        pass
                else:
                    pass
#----------------------------
#-------Cek sider biar mirip kek siri------------------#
            elif "Setlast" in msg.text:
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                cl.sendText(msg.to, "Checkpoint checked!")
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                print "Setlastpoint"

            elif "Viewlast" in msg.text:
               lurkGroup = ""
               dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
            with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%d日 %H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        grp = '\n• '.join(str(f) for f in dataResult)
                        total = '\nThese %iuesrs have seen at the lastseen\npoint(｀・ω・´)\n\n%s' % (len(dataResult), datetime.now().strftime('%H:%M:%S') )
                        cl.sendText(msg.to, "• %s %s" % (grp, total))
                    else:
                        cl.sendText(msg.to, "Sider ga bisa di read cek setpoint dulu bego tinggal ketik\nSetlastpoint\nkalo mau liat sider ketik\nViewlastseen")
                    print "Viewlastseen"

        if op.type == 55:
             try:
               group_id = op.param1
               user_id=op.param2
               subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
             except Exception as e:
               print e                    
#sc edit biar mirip sama kek siri:v(Har Har)
#---------CCTV-----------
#            elif msg.text == "Cek":
#              #if msg.from_ in admin:
#                cl.sendText(msg.to, "Cek the lastseens' point(｀・ω・´)\n「DONE」")
#                try:
#                  del wait2['readPoint'][msg.to]
#                  del wait2['readMember'][msg.to]
#                except:
#                  pass
#                now2 = datetime.now()
##                wait2['readPoint'][msg.to] = msg.id
#                wait2['readMember'][msg.to] = ""
#                wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
#                wait2['ROM'][msg.to] = {}
                #print wait2
              
#            elif msg.text == "Ctv":
#                 #if msg.from_ in admin:
#                    if msg.to in wait2['readPoint']:
#                        if wait2["ROM"][msg.to].items() == []:
#                            chiya = ""
#                        else:
#                            chiya = ""
#                            for rom in wait2["ROM"][msg.to].items():
#                                print rom
#                                chiya += rom[1] + "\n"

#                        cl.sendText(msg.to, "🔎 PROTECT SIDER 🔍 %s\n\n💮 LIST SIDER 💮\n%s\n\nReading point creation date n time:\n[%s]"  % (wait['readMember'][msg.to],chiya,setTime[msg.to]))
#                    else:
#                        cl.sendText(msg.to, "Untuk memulai awal silahkan ketik \n「Cek」")

        if op.type == 55:
            print "[NOTIFIED_READ_MESSAGE]"
            try:
                if op.param1 in wait2['readPoint']:
                    Nama = cl.getContact(op.param2).displayName
                    if Nama in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n〠 " + Nama
                        wait2['ROM'][op.param1][op.param2] = "〠 " + Nama
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                else:
                    cl.sendText
            except:
                pass

        if op.type == 59:
            print op


    except Exception as error:
        print error


def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
def autolike():
    for zx in range(0,200):
      hasil = cl.activity(limit=200)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          ki.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ki.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          ki2.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ki2.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          ki3.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ki3.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          ki4.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ki4.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          ki5.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ki5.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"👉Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
          print "Like"
        except:
          pass
      else:
          print "Already Liked"
time.sleep(0.01)
#thread3 = threading.Thread(target=autolike)
#thread3.daemon = True
#thread3.start()
#--------------------
def likePost():
    for zx in range(0,200):
        hasil = cl.activity(limit=200)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
            if hasil['result']['posts'][zx]['userInfo']['mid'] in owner:
                try:
                    cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    ki.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    ki2.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    ki3.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    ki4.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    ki5.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
                    cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto like by ╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣")
                    ki.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId']," ✰╠⌜◜ᵐ⁃ʳ◝◟🅱🅾🆃◞⌟╣✰")
                    print "Like"
                except:
                    pass
            else:
                print "Status Sudah di Like Plak"
                
def nameUpdate():
    while True:
        try:
        #while a2():
            #pass
            if wait["clock"] == True:
                now2 = datetime.now()
                nowT = datetime.strftime(now2,"(%H:%M)")
                profile = cl.getProfile()
                profile.displayName = wait["cName"]
                cl.updateProfile(profile)
            time.sleep(600)
        except:
            pass
thread2 = threading.Thread(target=nameUpdate)
thread2.daemon = True
thread2.start()

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
